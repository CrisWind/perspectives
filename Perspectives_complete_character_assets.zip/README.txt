Perspectives 人物素材交接说明

Perspectives_original_characters.zip：16 位角色的已有页面立绘和静态动作帧，解压后按角色查看。已有动作帧并未逐一确认动作含义，不能视为连续视频。
four_characters_seated.png：溯、弈、逆、晴的坐姿参考合图。
four_characters_pose_reference.png：四角色四状态静态参考图（行：溯、弈、逆、晴；列：点头、思考、说话、倾听）。
four_characters_transparent_sprite.png：上面状态图的透明背景版本，页面用其表现部分倾听状态。

以上不是 16 段连续动作视频，也不是完整动作骨骼文件。如需接入网页，须根据现有角色 ID 核对图片、测试裁切、透明边缘以及切换位置。自定义人物无固定立绘，应使用通用头像兜底。
