window.PERSPECTIVES_CONFIG = { apiBase: '' };
